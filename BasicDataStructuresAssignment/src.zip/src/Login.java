import java.util.Scanner;

public class Login {
public static void main(String[] args) {
	int count=0;
	if(count<=3) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the name");
	String s=sc.next();
	System.out.println("Enter the password");
	String s1=sc.next();
	if(s.equals("mani")&&s1.equals("mani123")) {
		System.out.println("Welcome");
	}
	else {
       
	}
}
}
}
